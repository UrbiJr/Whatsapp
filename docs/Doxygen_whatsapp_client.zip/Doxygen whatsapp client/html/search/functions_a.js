var searchData=
[
  ['send',['Send',['../socket_8h.html#ac2cc06713b6a1b83b9dad9e39637d5c2',1,'Send(int, const void *, int, int):&#160;socket.c'],['../socket_8c.html#a39f719f054da1c4e2f5c360a4335102d',1,'Send(int sockfd, const void *msg, int len, int flags):&#160;socket.c']]],
  ['set_5fdate',['set_date',['../message_8c.html#a447d0b0a77545a97acb91d1f6e222127',1,'message.c']]],
  ['set_5fday',['set_day',['../date_8c.html#a030ab8274240d74793776dc366694e41',1,'set_day(recDate *d, int n):&#160;date.c'],['../date_8h.html#ac51870424c333cba9a5ee3c3e6dfa5e6',1,'set_day(recDate *, int):&#160;date.c']]],
  ['set_5fhours',['set_hours',['../mytime_8h.html#a67ddc4ec583cdb52902d17818b222b05',1,'set_hours(recTime *, int):&#160;mytime.c'],['../mytime_8c.html#a23e2895b8fe353b60424f82ee81de909',1,'set_hours(recTime *t, int n):&#160;mytime.c']]],
  ['set_5fminutes',['set_minutes',['../mytime_8h.html#a49f6adc321fa84bfb5fc067bc06aada8',1,'set_minutes(recTime *, int):&#160;mytime.c'],['../mytime_8c.html#a8fe952df282cf9bd3de5f3b1bc006c67',1,'set_minutes(recTime *t, int n):&#160;mytime.c']]],
  ['set_5fmonth',['set_month',['../date_8c.html#a94ce1411dbd8ab86e68a45099f9a590c',1,'set_month(recDate *d, int n):&#160;date.c'],['../date_8h.html#a073dd26f3fdd45e2cf208548226fbfd2',1,'set_month(recDate *, int):&#160;date.c']]],
  ['set_5fname',['set_name',['../user_8h.html#a658c871a33ab843a8cb28929f02f1ea4',1,'set_name(recUser *, char *):&#160;user.c'],['../user_8c.html#aec8d17d94e792a8cffce79e2aace0ee9',1,'set_name(recUser *u, char *s):&#160;user.c']]],
  ['set_5fpassword',['set_password',['../user_8h.html#a970e22fab5bcfe4911a5ff80394afc08',1,'set_password(recUser *, char *):&#160;user.c'],['../user_8c.html#aab7d80d2517bb1c5757acf0b6345ebe0',1,'set_password(recUser *u, char *s):&#160;user.c']]],
  ['set_5freceiver',['set_receiver',['../message_8c.html#a0aaa9a00b206a8ff35c537a6382dc826',1,'message.c']]],
  ['set_5fsender',['set_sender',['../message_8c.html#af7620282215e42bdc1ae5d260f345c3f',1,'message.c']]],
  ['set_5fsurname',['set_surname',['../user_8h.html#af0644b8a08d0c8782116a33434610aaa',1,'set_surname(recUser *, char *):&#160;user.c'],['../user_8c.html#ab08faf83d800de558f92e72ea8dcc11e',1,'set_surname(recUser *u, char *s):&#160;user.c']]],
  ['set_5ftext',['set_text',['../message_8c.html#a7fc68483f62e1d0f0a92a8c2dff1f348',1,'message.c']]],
  ['set_5ftime',['set_time',['../message_8c.html#a844ae823e47c773ac0460711dd4b1b17',1,'message.c']]],
  ['set_5fusername',['set_username',['../user_8h.html#adb0920aa493b07d051c1760289b84913',1,'set_username(recUser *, char *):&#160;user.c'],['../user_8c.html#af98337fa03fb703ab58436df5ac86457',1,'set_username(recUser *u, char *s):&#160;user.c']]],
  ['set_5fyear',['set_year',['../date_8c.html#a8a37ab59b79e12e352d81dca3db63208',1,'set_year(recDate *d, int n):&#160;date.c'],['../date_8h.html#af782addb6a5061b45d0f298620676269',1,'set_year(recDate *, int):&#160;date.c']]],
  ['socket',['Socket',['../socket_8h.html#a65823a811ad6a1348143b349d03f859f',1,'Socket(int, int, int):&#160;socket.c'],['../socket_8c.html#ab40b825366ecd47b1693784284633633',1,'Socket(int domain, int type, int protocol):&#160;socket.c']]],
  ['store_5fusers',['store_users',['../user_8h.html#a9b14e2961eb9478d7e413e83d89d8da4',1,'store_users(FILE *, recUser *):&#160;user.c'],['../user_8c.html#a8b0e8475ce4338294b8f97cb5c5db6eb',1,'store_users(FILE *fp, recUser *u):&#160;user.c']]]
];
