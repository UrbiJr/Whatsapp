var searchData=
[
  ['listen',['Listen',['../socket_8h.html#a58eacdba1db52dd7e7a15e80a296c7d9',1,'Listen(int, int):&#160;socket.c'],['../socket_8c.html#a0d2550add1c0e62d5d615c891e6ea867',1,'Listen(int sockfd, int backlog):&#160;socket.c']]]
];
