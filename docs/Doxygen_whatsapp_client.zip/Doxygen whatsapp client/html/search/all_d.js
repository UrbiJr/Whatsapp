var searchData=
[
  ['text_2ec',['text.c',['../text_8c.html',1,'']]],
  ['text_2eh',['text.h',['../text_8h.html',1,'']]]
];
