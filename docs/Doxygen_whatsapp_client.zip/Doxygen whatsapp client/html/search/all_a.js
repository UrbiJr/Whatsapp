var searchData=
[
  ['open_5ffile',['open_file',['../in__out_8c.html#a3b24f5278cc33de07565a1c7c277ffeb',1,'in_out.c']]]
];
