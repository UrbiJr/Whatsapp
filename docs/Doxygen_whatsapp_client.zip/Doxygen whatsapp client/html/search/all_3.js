var searchData=
[
  ['date_2ec',['date.c',['../date_8c.html',1,'']]],
  ['date_2eh',['date.h',['../date_8h.html',1,'']]],
  ['define_5flanguage',['define_language',['../languages_8h.html#a3298756004f54e0ba476523799c2c36e',1,'define_language(int):&#160;languages.c'],['../languages_8c.html#ae80abc57c3c0ddbc46ecd8d9e30d811d',1,'define_language(int n):&#160;languages.c']]]
];
