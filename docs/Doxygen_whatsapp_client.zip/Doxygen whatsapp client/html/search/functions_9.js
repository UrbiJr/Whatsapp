var searchData=
[
  ['read_5fmessage_5ffrom_5ffile',['read_message_from_file',['../in__out_8c.html#a53284de7abbf4c461975a92f02b3b749',1,'in_out.c']]],
  ['readn',['readn',['../socket_8h.html#a2d3da88a2dcebb89422a4474247635a9',1,'readn(int, void *, size_t):&#160;socket.c'],['../socket_8c.html#a7f9d0d493bcf42462498cdc5b26d04a8',1,'readn(int sd, void *p, size_t n):&#160;socket.c']]],
  ['recv',['Recv',['../socket_8h.html#a4e3ab02f2703d45eca162d909aae1584',1,'Recv(int, void *, int, int):&#160;socket.c'],['../socket_8c.html#a2b65a9e258ead57f9ddda5cd3a5a85bb',1,'Recv(int sockfd, void *buf, int len, int flags):&#160;socket.c']]],
  ['remove_5fmessage',['remove_message',['../message_8c.html#a20a45975eb974bf0e9cef6baf2f2dbe1',1,'message.c']]]
];
