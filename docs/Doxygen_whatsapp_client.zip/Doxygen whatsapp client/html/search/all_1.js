var searchData=
[
  ['bind',['Bind',['../socket_8h.html#ac0c7efdd9f9f771cb7531e06d63a336f',1,'Bind(int, struct sockaddr *, int):&#160;socket.c'],['../socket_8c.html#ae9b7c042bd27d28c3bb80f9e21fbedd5',1,'Bind(int sockfd, struct sockaddr *my_addr, int addrlen):&#160;socket.c']]],
  ['bind_5fserver_5fsocket',['bind_server_socket',['../socket_8h.html#a137c3afa6a1b0c986b3b83d78a451722',1,'bind_server_socket(char *):&#160;socket.c'],['../socket_8c.html#a13a24f4295bde425f89333cd64ba4613',1,'bind_server_socket(char *port):&#160;socket.c']]]
];
