var searchData=
[
  ['get_5fdate',['get_date',['../message_8c.html#abb386c1b62a1be75882c2da954acb551',1,'message.c']]],
  ['get_5fday',['get_day',['../date_8c.html#a2782bb46144d1a300e698a731877554c',1,'get_day(recDate *d):&#160;date.c'],['../date_8h.html#a2c425f60cf131ba21c3578439174a09b',1,'get_day(recDate *):&#160;date.c']]],
  ['get_5fhours',['get_hours',['../mytime_8h.html#a48e7187a780259b369efbb5356ca6fc7',1,'get_hours(recTime *):&#160;mytime.c'],['../mytime_8c.html#a165bf14a62cf5b6bbc52f171b31ae846',1,'get_hours(recTime *t):&#160;mytime.c']]],
  ['get_5fin_5faddr',['get_in_addr',['../socket_8h.html#a4cec2c36744ecf3accef9400077edd2f',1,'get_in_addr(struct sockaddr *):&#160;socket.c'],['../socket_8c.html#a294867ba9d7ff47e39d421134d8e12ab',1,'get_in_addr(struct sockaddr *sa):&#160;socket.c']]],
  ['get_5fminutes',['get_minutes',['../mytime_8h.html#a872ef734b6c04a7cb57d1b1521f75c41',1,'get_minutes(recTime *):&#160;mytime.c'],['../mytime_8c.html#a589f11ef40ad2db2d71d66c3bdae9f4d',1,'get_minutes(recTime *t):&#160;mytime.c']]],
  ['get_5fmonth',['get_month',['../date_8c.html#a8c445f7986b0a295adc42969e7f43bfd',1,'get_month(recDate *d):&#160;date.c'],['../date_8h.html#a039d494d8764799d339b5d6d54d5968f',1,'get_month(recDate *):&#160;date.c']]],
  ['get_5fname',['get_name',['../user_8h.html#a908a11e8517da5b605b27fb6db06b772',1,'get_name(recUser *):&#160;user.c'],['../user_8c.html#a3ae19128d3193ffe991658b9e3fc881c',1,'get_name(recUser *u):&#160;user.c']]],
  ['get_5fpassword',['get_password',['../user_8h.html#a03d556725755e5869338cb1d8b7407e2',1,'get_password(recUser *):&#160;user.c'],['../user_8c.html#ac67720613d52f82f924090d97063cf91',1,'get_password(recUser *u):&#160;user.c']]],
  ['get_5freceiver',['get_receiver',['../message_8c.html#a274f0f385bb402e7218779ad3c1af21b',1,'message.c']]],
  ['get_5fsender',['get_sender',['../message_8c.html#a5054384f302254883542ca4da75bbb4b',1,'message.c']]],
  ['get_5fstring',['get_string',['../text_8h.html#a9bcf511c82048ca2825ed22fd867e3d9',1,'get_string(recText *):&#160;text.c'],['../text_8c.html#ad7250e7b19c49c4f46136836b37294f6',1,'get_string(recText *t):&#160;text.c']]],
  ['get_5fsurname',['get_surname',['../user_8h.html#abfc7e32c7fb49556709cac9d699272d8',1,'get_surname(recUser *):&#160;user.c'],['../user_8c.html#a4fa4bcaea7c1ea2d23d949d738955c27',1,'get_surname(recUser *u):&#160;user.c']]],
  ['get_5ftext',['get_text',['../message_8c.html#a43850431640cef17c4fa7c841d83263b',1,'message.c']]],
  ['get_5ftime',['get_time',['../message_8c.html#a5ce91ace54bb9670a076e7f06ef30578',1,'message.c']]],
  ['get_5fusername',['get_username',['../user_8h.html#a66e332c3a33c17d9fe6bfdd8f3abfbea',1,'get_username(recUser *):&#160;user.c'],['../user_8c.html#aeaef4843afb84ef0e474cddf3e5237b9',1,'get_username(recUser *u):&#160;user.c']]],
  ['get_5fyear',['get_year',['../date_8c.html#a3ab0b30447553bfaffc15f9467810a21',1,'get_year(recDate *d):&#160;date.c'],['../date_8h.html#a7355222ef55d47fcb712f0d5c04b14d7',1,'get_year(recDate *):&#160;date.c']]],
  ['getaddrinfo',['Getaddrinfo',['../socket_8h.html#adbc58e6a0857b5534257084a96fa6d40',1,'Getaddrinfo(const char *, const char *, const struct addrinfo *, struct addrinfo **):&#160;socket.c'],['../socket_8c.html#a37b56d2bc0cf587b0137b9087556dfef',1,'Getaddrinfo(const char *node, const char *service, const struct addrinfo *hints, struct addrinfo **res):&#160;socket.c']]]
];
