var searchData=
[
  ['date_2ec',['date.c',['../date_8c.html',1,'']]],
  ['date_2eh',['date.h',['../date_8h.html',1,'']]]
];
