var searchData=
[
  ['find_5fmessage',['find_message',['../message_8c.html#aa7f5153fc2f63fcedd2e78a712fdce56',1,'message.c']]],
  ['find_5fusername',['find_username',['../user_8h.html#ac7e8a7af900e4c91c5b289e726b8c203',1,'find_username(FILE *, char *):&#160;user.c'],['../user_8c.html#aff8d29641fc8f48b478a576743a5465e',1,'find_username(FILE *fp, char *username):&#160;user.c']]]
];
