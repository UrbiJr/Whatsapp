var searchData=
[
  ['accept',['Accept',['../socket_8h.html#adae2e97a9d2e8c429084a4899242dcd3',1,'Accept(int, struct sockaddr *, socklen_t *):&#160;socket.c'],['../socket_8c.html#a01855882d3cc0aa58978014fae447f48',1,'Accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen):&#160;socket.c']]]
];
