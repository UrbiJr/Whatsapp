var searchData=
[
  ['check_5finline_5fparameters',['check_inline_parameters',['../socket_8h.html#a53196e2c743e501d06f1b67d436713af',1,'check_inline_parameters(int, int):&#160;socket.c'],['../socket_8c.html#a7d3ec6e028483b8a88bed9b99229f2f1',1,'check_inline_parameters(int expected, int argc):&#160;socket.c']]],
  ['close_5ffile',['close_file',['../in__out_8c.html#ab720e65bff6b2fbac4fc7dadf6ea1f63',1,'in_out.c']]],
  ['connect',['Connect',['../socket_8h.html#a292263a95066ed701fdc3028c56391f5',1,'Connect(int, struct addrinfo **):&#160;socket.c'],['../socket_8c.html#ac6a7964c0f840ffd205a7e555a98b6b9',1,'Connect(int sockfd, struct addrinfo **res):&#160;socket.c']]],
  ['connect_5fto_5fserver',['connect_to_server',['../socket_8h.html#a28be59b6486421fa860cc81975d29b8a',1,'connect_to_server(char *, char *):&#160;socket.c'],['../socket_8c.html#ae3bfb94277717fa1601b42326c58890b',1,'connect_to_server(char *servAddr, char *servPort):&#160;socket.c']]],
  ['constants_2eh',['constants.h',['../constants_8h.html',1,'']]],
  ['copy_5ffile',['copy_file',['../in__out_8c.html#a23e75e834ac43a53a0ef0d64a5e8a5b9',1,'in_out.c']]]
];
