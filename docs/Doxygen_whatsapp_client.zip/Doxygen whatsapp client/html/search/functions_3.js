var searchData=
[
  ['define_5flanguage',['define_language',['../languages_8h.html#a3298756004f54e0ba476523799c2c36e',1,'define_language(int):&#160;languages.c'],['../languages_8c.html#ae80abc57c3c0ddbc46ecd8d9e30d811d',1,'define_language(int n):&#160;languages.c']]]
];
