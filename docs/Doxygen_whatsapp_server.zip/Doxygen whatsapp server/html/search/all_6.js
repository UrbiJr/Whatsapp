var searchData=
[
  ['ncurses_5finit',['ncurses_init',['../mycurses_8h.html#a30bd87509aa72ff731067e22a0774b29',1,'ncurses_init(void):&#160;mycurses.c'],['../mycurses_8c.html#a2426a1120a129e26b07f900a1374128f',1,'ncurses_init(void):&#160;mycurses.c']]],
  ['ncurses_5finit_5fcolors',['ncurses_init_colors',['../mycurses_8h.html#aa4b9b8daf20c54b5214cbf7dc77c8c4e',1,'ncurses_init_colors(void):&#160;mycurses.c'],['../mycurses_8c.html#a19e9332b4eb268c2912e04b310ea4721',1,'ncurses_init_colors(void):&#160;mycurses.c']]],
  ['ncurses_5funread_5fmessages',['ncurses_unread_messages',['../mycurses_8h.html#a03b4ea3983183b79e3dc20f2bda8394a',1,'ncurses_unread_messages(WINDOW *, recMessage *, int *):&#160;mycurses.c'],['../mycurses_8c.html#a37fdb5806dd3ca94091a8d12bfc6ff7a',1,'ncurses_unread_messages(WINDOW *local_win, recMessage *msg, int *n_mes):&#160;mycurses.c']]]
];
