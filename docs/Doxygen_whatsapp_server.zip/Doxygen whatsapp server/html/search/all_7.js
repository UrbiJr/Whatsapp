var searchData=
[
  ['recconnecteduser',['recConnectedUser',['../structrec_connected_user.html',1,'']]],
  ['reccurrentlanguage',['recCurrentLanguage',['../structrec_current_language.html',1,'']]],
  ['recdate',['recDate',['../structrec_date.html',1,'']]],
  ['recmessage',['recMessage',['../structrec_message.html',1,'']]],
  ['rectext',['recText',['../structrec_text.html',1,'']]],
  ['rectime',['recTime',['../structrec_time.html',1,'']]],
  ['recuser',['recUser',['../structrec_user.html',1,'']]]
];
